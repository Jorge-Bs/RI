Uo293697
Jorge Blanco Sánchez
Ejercicio 1