package uo.ri.cws.application.service.util.sql.base;

public interface PositionalBinding {

	int FIRST_PARAMETER = 1;
	int SECOND_PARAMETER = 2;
	int THIRD_PARAMETER = 3;
	int FOURTH_PARAMETER = 4;
	int FIFTH_PARAMETER = 5;

}
