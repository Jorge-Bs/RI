package uo.ri.cws.application.service.spare.sparepart;

import java.util.Optional;

import uo.ri.cws.application.service.spare.SparePartCrudService;
import uo.ri.util.exception.BusinessException;

public class SparePartCrudServiceImpl implements SparePartCrudService {

	@Override
	public SparePartDto add(SparePartDto dto) throws BusinessException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(String code) throws BusinessException {
		// TODO Auto-generated method stub

	}

	@Override
	public void update(SparePartDto dto) throws BusinessException {
		// TODO Auto-generated method stub

	}

	@Override
	public Optional<SparePartDto> findByCode(String code) throws BusinessException {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

}
