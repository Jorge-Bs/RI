package uo.ri.cws.domain.base;

public enum EntityState {
	ENABLED, 
	DISABLED
}
