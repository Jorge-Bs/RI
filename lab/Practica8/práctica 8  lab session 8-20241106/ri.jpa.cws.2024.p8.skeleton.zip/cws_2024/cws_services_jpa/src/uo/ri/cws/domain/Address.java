package uo.ri.cws.domain;

public class Address {

}
