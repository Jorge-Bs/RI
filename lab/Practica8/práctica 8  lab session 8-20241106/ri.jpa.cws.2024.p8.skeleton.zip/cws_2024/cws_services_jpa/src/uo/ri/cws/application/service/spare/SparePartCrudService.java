package uo.ri.cws.application.service.spare;

/**
 * This service is intended to be used by the Manager
 * It follows the ISP principle (@see SOLID principles from RC Martin)
 */
public interface SparePartCrudService {

	// ... not yet defined

}
