package uo.ri.cws.application.ui.foreman.action;

import uo.ri.util.exception.BusinessException;
import uo.ri.util.menu.Action;

public class AddWorkOrderAction implements Action {

	@Override
	public void execute() throws BusinessException {
		// TODO Auto-generated method stub
		
	}

}
