package uo.ri.cws.application.service.mechanic.crud;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import uo.ri.cws.application.service.mechanic.MechanicCrudService.MechanicDto;

public class DtoAssembler {

    public static MechanicDto toDto(ResultSet rs) throws SQLException {
	MechanicDto res = new MechanicDto();
	res.id = rs.getString("id");
	res.version = rs.getLong("version");

	res.nif = rs.getString("nif");
	res.name = rs.getString("name");
	res.surname = rs.getString("surname");
	return res;
    }

    public static List<MechanicDto> toDtoList(ResultSet rs)
	    throws SQLException {
	List<MechanicDto> res = new ArrayList<>();
	while (rs.next()) {
	    res.add(toDto(rs));
	}
	return res;
    }
}
