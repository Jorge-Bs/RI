package uo.ri.cws.application.service.invoice.create.commands;

public class FindNotInvoicedWorkOrders {

}
